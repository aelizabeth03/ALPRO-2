import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

class Kendaraan:
    def __init__(self, jenis, roda, bahan_bakar, warna):
        self.jenis = jenis
        self.roda = roda
        self.bahan_bakar = bahan_bakar
        self.warna = warna

class Mobil(Kendaraan):
    def __init__(self, jenis, roda, bahan_bakar, warna, kapasitas_penumpang, gambar):
        super().__init__(jenis, roda, bahan_bakar, warna)
        self.kapasitas_penumpang = kapasitas_penumpang
        self.gambar = gambar

class Motor(Kendaraan):
    def __init__(self, jenis, roda, bahan_bakar, warna, jenis_stang, gambar):
        super().__init__(jenis, roda, bahan_bakar, warna)
        self.jenis_stang = jenis_stang
        self.gambar = gambar

class Truk(Kendaraan):
    def __init__(self, jenis, roda, bahan_bakar, warna, muatan_maksimum, gambar):
        super().__init__(jenis, roda, bahan_bakar, warna)
        self.muatan_maksimum = muatan_maksimum
        self.gambar = gambar

def tampilkan_kendaraan(kendaraan_list, title):
    window = tk.Toplevel()
    window.title(title)
    
    frame = ttk.Frame(window, padding=10)
    frame.grid(row=0, column=0)

    row = 0
    for kendaraan in kendaraan_list:
        img = Image.open(kendaraan.gambar)
        img = img.resize((200, 120))
        photo = ImageTk.PhotoImage(img)

        img_label = ttk.Label(frame, image=photo)
        img_label.image = photo
        img_label.grid(row=row, column=0, padx=10, pady=10)

        if kendaraan.bahan_bakar.lower() == "listrik":
            bahan = f"E-Fuel: {kendaraan.bahan_bakar}"
        else:
            bahan = f"Bahan Bakar: {kendaraan.bahan_bakar}"

        spec = f"Jenis: {kendaraan.jenis}\n" \
               f"Jumlah Roda: {kendaraan.roda}\n" \
               f"{bahan}\n" \
               f"Warna: {kendaraan.warna}\n"
        
        if isinstance(kendaraan, Mobil):
            spec += f"Kapasitas Penumpang: {kendaraan.kapasitas_penumpang}"
        elif isinstance(kendaraan, Motor):
            spec += f"Jenis Stang: {kendaraan.jenis_stang}"
        elif isinstance(kendaraan, Truk):
            spec += f"Muatan Maksimum: {kendaraan.muatan_maksimum}"

        text_label = ttk.Label(frame, text=spec, justify="left")
        text_label.grid(row=row, column=1, padx=10, pady=10, sticky="w")

        row += 1

    exit_button = ttk.Button(frame, text="Keluar", command=window.destroy)
    exit_button.grid(row=row, column=1, pady=20, sticky="e")

def main_menu():
    root = tk.Tk()
    root.title("Program Kendaraan")

    frame = ttk.Frame(root, padding=20)
    frame.pack()

    label = ttk.Label(frame, text="Pilih Jenis Kendaraan", font=("Helvetica", 16))
    label.pack(pady=10)

    def open_mobil():
        mobil_list = [
            Mobil("Mobil Elektrik", 4, "Listrik", "Putih", 5, "elektrikMobili.jpg"),
            Mobil("Mobil Berbahan Bakar", 4, "Bensin", "Silver", 7, "BensinMobil.jpg"),
            Mobil("Mobil Diesel", 4, "Diesel", "Abu-abu", 6, "DiselMobil.jpg"),
        ]
        tampilkan_kendaraan(mobil_list, "Daftar Mobil")

    def open_motor():
        motor_list = [
            Motor("Motor Elektrik", 2, "Listrik", "Hijau", "Stang Motor", "MotorListrik.jpg"),
            Motor("Motor Berbahan Bakar", 2, "Bensin", "Merah", "Stang Jengki", "MotorBensin.jpg"),
        ]
        tampilkan_kendaraan(motor_list, "Daftar Motor")

    def open_truk():
        truk_list = [
            Truk("Light Truck", 6, "Diesel", "Kuning", "5000 kg", "Light-Truck.jpg"),
            Truk("Medium Truck", 10, "Diesel", "Merah", "12000 kg", "MediumTruck.jpg"),
            Truk("Heavy Truck", 14, "Diesel", "Putih", "18000 kg", "HeavyTruck.jpg"),
        ]
        tampilkan_kendaraan(truk_list, "Daftar Truk")

    ttk.Button(frame, text="Mobil", width=20, command=open_mobil).pack(pady=5)
    ttk.Button(frame, text="Motor", width=20, command=open_motor).pack(pady=5)
    ttk.Button(frame, text="Truk", width=20, command=open_truk).pack(pady=5)

    root.mainloop()

if __name__ == "__main__":
    main_menu()
